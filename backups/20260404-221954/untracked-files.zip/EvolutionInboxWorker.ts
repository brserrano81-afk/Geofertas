import dotenv from 'dotenv';
import {
    addDoc,
    collection,
    doc,
    getDocs,
    limit,
    query,
    serverTimestamp,
    updateDoc,
    where,
} from 'firebase/firestore';

import { db } from '../firebase';
import { chatService } from '../services/ChatService';

dotenv.config();

interface InboxMessage {
    userId: string;
    remoteJid: string;
    messageType?: string;
    text?: string;
    mediaBase64?: string | null;
    mediaUrl?: string | null;
    status?: string;
    event?: string;
    source?: string;
}

interface OutboxMessage {
    inboxId: string;
    userId: string;
    remoteJid: string;
    text: string;
    sendStatus?: 'pending_send' | 'sent' | 'send_failed';
    evolutionRequest?: unknown;
    evolutionResponse?: unknown;
    error?: string | null;
}

const POLL_INTERVAL_MS = Number(process.env.EVOLUTION_WORKER_POLL_MS || 4000);
const RUN_ONCE = process.argv.includes('--once');
const VERBOSE = process.argv.includes('--verbose');
const EVOLUTION_SEND_FORMAT = (process.env.EVOLUTION_SEND_FORMAT || 'auto').toLowerCase();
const EVOLUTION_TYPING_ENABLED = process.env.EVOLUTION_TYPING_ENABLED !== 'false';
const EVOLUTION_TYPING_MS = Number(process.env.EVOLUTION_TYPING_MS || 1500);

function sanitizePhoneNumber(remoteJid: string): string {
    const digits = String(remoteJid || '').split('@')[0].replace(/\D/g, '');
    if (digits.length === 11 && !digits.startsWith('55')) {
        return `55${digits}`;
    }
    return digits;
}

function getEvolutionSendUrl(): string | null {
    if (process.env.EVOLUTION_SEND_TEXT_URL) {
        return process.env.EVOLUTION_SEND_TEXT_URL;
    }

    const baseUrl = process.env.EVOLUTION_API_BASE_URL;
    const instance =
        process.env.EVOLUTION_SEND_INSTANCE ||
        process.env.EVOLUTION_INSTANCE ||
        process.env.EVOLUTION_INSTANCE_ID;
    if (!baseUrl || !instance) {
        return null;
    }

    return `${baseUrl.replace(/\/$/, '')}/message/sendText/${instance}`;
}

function getEvolutionPresenceUrl(): string | null {
    const baseUrl = process.env.EVOLUTION_API_BASE_URL;
    const instance =
        process.env.EVOLUTION_SEND_INSTANCE ||
        process.env.EVOLUTION_INSTANCE ||
        process.env.EVOLUTION_INSTANCE_ID;
    if (!baseUrl || !instance) {
        return null;
    }

    return `${baseUrl.replace(/\/$/, '')}/chat/sendPresence/${instance}`;
}

async function loadPendingMessages(): Promise<Array<{ id: string; data: InboxMessage }>> {
    const inboxRef = collection(db, 'message_inbox');
    const pendingQuery = query(inboxRef, where('status', '==', 'pending'), limit(5));
    const snap = await getDocs(pendingQuery);

    return snap.docs
        .map((docSnap) => ({
            id: docSnap.id,
            data: docSnap.data() as InboxMessage,
        }))
        .sort((a, b) => {
            const aTime = String((a.data as any).receivedAtIso || '');
            const bTime = String((b.data as any).receivedAtIso || '');
            return aTime.localeCompare(bTime);
        });
}

async function loadPendingOutboxMessages(): Promise<Array<{ id: string; data: OutboxMessage }>> {
    const outboxRef = collection(db, 'message_outbox');
    const pendingQuery = query(outboxRef, where('sendStatus', '==', 'pending_send'), limit(10));
    const snap = await getDocs(pendingQuery);

    return snap.docs
        .map((docSnap) => ({
            id: docSnap.id,
            data: docSnap.data() as OutboxMessage,
        }))
        .sort((a, b) => a.id.localeCompare(b.id));
}

async function markInboxStatus(id: string, status: string, extra: Record<string, unknown> = {}) {
    const inboxDoc = doc(db, 'message_inbox', id);
    await updateDoc(inboxDoc, {
        status,
        ...(status === 'error' ? {} : { error: null }),
        updatedAt: serverTimestamp(),
        ...extra,
    });
}

async function markOutboxStatus(id: string, status: OutboxMessage['sendStatus'], extra: Record<string, unknown> = {}) {
    const outboxDoc = doc(db, 'message_outbox', id);
    await updateDoc(outboxDoc, {
        sendStatus: status,
        ...(status === 'send_failed' ? {} : { error: null }),
        updatedAt: serverTimestamp(),
        ...extra,
    });
}

async function persistOutboxMessage(inboxId: string, payload: {
    userId: string;
    remoteJid: string;
    text: string;
    sendStatus: 'pending_send' | 'sent' | 'send_failed';
    evolutionRequest?: unknown;
    evolutionResponse?: unknown;
    error?: string | null;
}) {
    await addDoc(collection(db, 'message_outbox'), {
        inboxId,
        source: 'economizafacil-worker',
        userId: payload.userId,
        remoteJid: payload.remoteJid,
        text: payload.text,
        sendStatus: payload.sendStatus,
        evolutionRequest: payload.evolutionRequest || null,
        evolutionResponse: payload.evolutionResponse || null,
        error: payload.error || null,
        createdAt: serverTimestamp(),
    });
}

async function postEvolutionText(
    sendUrl: string,
    headers: Record<string, string>,
    body: Record<string, unknown>,
) {
    const response = await fetch(sendUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify(body),
    });

    const rawText = await response.text();
    let parsedResponse: unknown = rawText;

    try {
        parsedResponse = JSON.parse(rawText);
    } catch {
        parsedResponse = rawText;
    }

    return {
        ok: response.ok,
        statusCode: response.status,
        requestBody: body,
        parsedResponse,
        rawText,
    };
}

async function sendPresenceViaEvolution(remoteJid: string) {
    if (!EVOLUTION_TYPING_ENABLED) {
        return;
    }

    const presenceUrl = getEvolutionPresenceUrl();
    if (!presenceUrl) {
        return;
    }

    const apiKey = process.env.EVOLUTION_API_KEY || process.env.EVOLUTION_APIKEY || '';
    const apiKeyHeader = process.env.EVOLUTION_API_KEY_HEADER || 'apikey';
    const number = sanitizePhoneNumber(remoteJid);

    const headers: Record<string, string> = {
        'Content-Type': 'application/json',
    };

    if (apiKey) {
        headers[apiKeyHeader] = apiKey;
    }

    const response = await fetch(presenceUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify({
            number,
            options: {
                delay: EVOLUTION_TYPING_MS,
                presence: 'composing',
            },
        }),
    });

    if (!response.ok && VERBOSE) {
        const rawText = await response.text();
        console.warn(`[EvolutionInboxWorker] sendPresence falhou (${response.status}): ${rawText}`);
    }
}

async function sendTextViaEvolution(remoteJid: string, text: string) {
    const sendUrl = getEvolutionSendUrl();
    if (!sendUrl) {
        return { attempted: false, status: 'pending_send' as const };
    }

    const apiKey = process.env.EVOLUTION_API_KEY || process.env.EVOLUTION_APIKEY || '';
    const apiKeyHeader = process.env.EVOLUTION_API_KEY_HEADER || 'apikey';
    const number = sanitizePhoneNumber(remoteJid);

    const requestBody = {
        number,
        text,
    };

    const headers: Record<string, string> = {
        'Content-Type': 'application/json',
    };

    if (apiKey) {
        headers[apiKeyHeader] = apiKey;
    }

    const requestBodies =
        EVOLUTION_SEND_FORMAT === 'v1'
            ? [{
                number,
                textMessage: { text },
                options: {
                    delay: EVOLUTION_TYPING_MS,
                    presence: 'composing',
                },
            }]
            : EVOLUTION_SEND_FORMAT === 'v2'
                ? [{
                    ...requestBody,
                    delay: EVOLUTION_TYPING_MS,
                }]
                : [
                    {
                        ...requestBody,
                        delay: EVOLUTION_TYPING_MS,
                    },
                    {
                        number,
                        textMessage: { text },
                        options: {
                            delay: EVOLUTION_TYPING_MS,
                            presence: 'composing',
                        },
                    },
                ];

    let lastFailure: { statusCode: number; rawText: string } | null = null;

    for (const candidateBody of requestBodies) {
        const result = await postEvolutionText(sendUrl, headers, candidateBody);
        if (result.ok) {
            return {
                attempted: true,
                status: 'sent' as const,
                requestBody: result.requestBody,
                parsedResponse: result.parsedResponse,
            };
        }

        lastFailure = {
            statusCode: result.statusCode,
            rawText: result.rawText,
        };

        if (VERBOSE) {
            console.warn(
                `[EvolutionInboxWorker] Tentativa sendText falhou (${result.statusCode}) com payload ${JSON.stringify(candidateBody)}`,
            );
        }
    }

    throw new Error(
        `Evolution send failed (${lastFailure?.statusCode || 'unknown'}): ${lastFailure?.rawText || 'no response body'}`,
    );
}

async function buildResponse(message: InboxMessage): Promise<string> {
    if (message.messageType === 'imageMessage' && message.mediaBase64) {
        const buffer = Buffer.from(message.mediaBase64, 'base64');
        const response = await chatService.processImage(new Uint8Array(buffer), message.userId);
        return response.text;
    }

    const text = String(message.text || '').trim();
    if (!text) {
        return 'Recebi sua mensagem, mas ainda não consegui interpretar esse formato. Pode mandar em texto ou imagem?';
    }

    const response = await chatService.processMessage(text, message.userId);
    return response.text;
}

async function processInboxItem(item: { id: string; data: InboxMessage }) {
    const { id, data } = item;

    await markInboxStatus(id, 'processing');

    try {
        await sendPresenceViaEvolution(data.remoteJid);
        const responseText = await buildResponse(data);
        const sendResult = await sendTextViaEvolution(data.remoteJid, responseText);

        await persistOutboxMessage(id, {
            userId: data.userId,
            remoteJid: data.remoteJid,
            text: responseText,
            sendStatus: sendResult.status,
            evolutionRequest: 'requestBody' in sendResult ? sendResult.requestBody : null,
            evolutionResponse: 'parsedResponse' in sendResult ? sendResult.parsedResponse : null,
            error: null,
        });

        await markInboxStatus(id, sendResult.status === 'sent' ? 'done' : 'awaiting_send', {
            responsePreview: responseText.slice(0, 200),
            processedAt: serverTimestamp(),
        });

        console.log(`[EvolutionInboxWorker] Inbox ${id} processada para ${data.remoteJid} (${sendResult.status}).`);
    } catch (err: any) {
        console.error(`[EvolutionInboxWorker] Erro ao processar inbox ${id}:`, err);

        await persistOutboxMessage(id, {
            userId: data.userId,
            remoteJid: data.remoteJid,
            text: '',
            sendStatus: 'send_failed',
            error: err.message || 'unknown_error',
        });

        await markInboxStatus(id, 'error', {
            error: err.message || 'unknown_error',
            failedAt: serverTimestamp(),
        });
    }
}

async function processPendingBatch() {
    const pending = await loadPendingMessages();
    if (VERBOSE) {
        console.log(`[EvolutionInboxWorker] Pending inbox count: ${pending.length}`);
    }
    if (pending.length === 0) {
        return;
    }

    for (const item of pending) {
        await processInboxItem(item);
    }
}

async function flushPendingOutboxBatch() {
    const sendUrl = getEvolutionSendUrl();
    if (!sendUrl) {
        if (VERBOSE) {
            console.log('[EvolutionInboxWorker] Evolution send URL ausente. Outbox pendente sera mantido.');
        }
        return;
    }

    const pending = await loadPendingOutboxMessages();
    if (VERBOSE) {
        console.log(`[EvolutionInboxWorker] Pending outbox count: ${pending.length}`);
    }
    if (pending.length === 0) {
        return;
    }

    for (const item of pending) {
        try {
            const sendResult = await sendTextViaEvolution(item.data.remoteJid, item.data.text);
            await markOutboxStatus(item.id, sendResult.status, {
                evolutionRequest: 'requestBody' in sendResult ? sendResult.requestBody : null,
                evolutionResponse: 'parsedResponse' in sendResult ? sendResult.parsedResponse : null,
                error: null,
            });
            await markInboxStatus(item.data.inboxId, sendResult.status === 'sent' ? 'done' : 'awaiting_send', {
                responsePreview: item.data.text.slice(0, 200),
                processedAt: serverTimestamp(),
            });

            console.log(`[EvolutionInboxWorker] Outbox ${item.id} reenviado para ${item.data.remoteJid} (${sendResult.status}).`);
        } catch (err: any) {
            console.error(`[EvolutionInboxWorker] Erro ao reenviar outbox ${item.id}:`, err);
            await markOutboxStatus(item.id, 'send_failed', {
                error: err.message || 'unknown_error',
            });
            await markInboxStatus(item.data.inboxId, 'error', {
                error: err.message || 'unknown_error',
                failedAt: serverTimestamp(),
            });
        }
    }
}

async function main() {
    console.log(
        `[EvolutionInboxWorker] Iniciado. Poll interval: ${POLL_INTERVAL_MS}ms${RUN_ONCE ? ' | modo: once' : ''}${VERBOSE ? ' | verbose' : ''}`,
    );

    await processPendingBatch();
    await flushPendingOutboxBatch();
    if (RUN_ONCE) {
        console.log('[EvolutionInboxWorker] Execucao unica concluida.');
        return;
    }

    setInterval(() => {
        Promise.all([
            processPendingBatch(),
            flushPendingOutboxBatch(),
        ]).catch((err) => {
            console.error('[EvolutionInboxWorker] Loop error:', err);
        });
    }, POLL_INTERVAL_MS);
}

main().catch((err) => {
    console.error('[EvolutionInboxWorker] Fatal error:', err);
    process.exit(1);
});
