// ─────────────────────────────────────────────
// ChatService — Orquestrador Puro
// Recebe NlpResult → delega para engine correto
// → retorna ChatResponse.
// ─────────────────────────────────────────────

import { diagnosticService } from './DiagnosticService';
import { aiService, type Intent } from './AiService';
import { offerEngine } from './OfferEngine';
import { ListManager } from './ListManager';
import { PurchaseManager } from './PurchaseManager';
import { ingestionPipeline } from './IngestionPipeline';
import { matchReceiptToList, type MatchResult } from './ReceiptMatcher';
import { ConversationStateService } from './ConversationStateService';
import { PurchaseAnalyticsService } from './PurchaseAnalyticsService';
import { userPreferencesService } from './UserPreferencesService';
import { userProfileService } from './UserProfileService';
import { userContextService } from './UserContextService';
import { predictiveShoppingService } from './PredictiveShoppingService';
import { geoDecisionEngine } from './GeoDecisionEngine';
import { type TransportMode, calculateAllTransportCosts } from '../app/utils/geoUtils';

export interface ChatResponse {
    text: string;
    shareContent?: string;
    requestLocation?: boolean; // Se true, o front dispara o GPS
}

interface ListItem {
    name: string;
    quantity?: number;
    unit?: string;
    priceAtacadao?: number;
    priceExtrabom?: number;
}

interface UserLocation {
    lat: number;
    lng: number;
    address?: string;
}

interface ChatContext {
    shoppingList: ListItem[];
    lastProduct?: string;
    userId: string;
    userName?: string;
    pendingPurchase?: any;
    pendingMatchResult?: MatchResult;
    pendingAllProducts?: string[];
    lastIntent?: Intent;
    userLocation?: UserLocation;
    transportMode?: TransportMode;
    consumption?: number;
    busTicket?: number;
    lastEconomicResult?: any;
    richContextSummary?: string;
    predictedNeeds?: Array<{ product: string; daysRemaining: number; urgent: boolean }>;
}

// Palavras que NUNCA devem ser adicionadas como item de lista
const GARBAGE_WORDS = new Set([
    'ver lista', 'mostrar lista', 'minha lista', 'adicionar', 'eu', 'usar',
    'ok', 'sim', 'bora', 'pode', 'quero', 'finalizar', 'pronto', 'fechar',
    'lista', 'ver', 'mostrar', 'obrigado', 'valeu', 'oi', 'ola', 'tchau',
    'nao', 'não', 'cancelar', 'voltar', 'ajuda', 'help',
    'bom dia', 'boa tarde', 'boa noite', 'e ai', 'e aí', 'olá',
]);

const COURTESY_WORDS = new Set([
    'oi', 'ola', 'olá', 'bom dia', 'boa tarde', 'boa noite', 'obrigado',
    'obrigada', 'valeu', 'e ai', 'e aí', 'show', 'blz', 'beleza',
]);

/** Remove duplicatas (case-insensitive) e filtra garbage words */
function cleanProductList(products: string[]): string[] {
    const seen = new Set<string>();
    const result: string[] = [];
    for (const p of products) {
        const key = p.toLowerCase().trim();
        if (key.length < 2) continue;
        if (GARBAGE_WORDS.has(key)) continue;
        if (seen.has(key)) continue;
        seen.add(key);
        result.push(p.trim());
    }
    return result;
}

class ChatSession {
    private static diagnosticsChecked = false;

    private context: ChatContext;
    private readonly conversationState = new ConversationStateService();
    private readonly listManager: ListManager;
    private readonly purchaseManager: PurchaseManager;
    private readonly purchaseAnalytics: PurchaseAnalyticsService;
    private readonly ready: Promise<void>;
    private lastContextRefreshAt = 0;

    constructor(userId: string = 'default_user') {
        this.context = {
            shoppingList: [],
            userId,
            transportMode: 'car',
            consumption: 10,
        };

        this.listManager = new ListManager(userId);
        this.purchaseManager = new PurchaseManager(userId);
        this.purchaseAnalytics = new PurchaseAnalyticsService(userId);

        if (!ChatSession.diagnosticsChecked) {
            diagnosticService.runFullCheck();
            ChatSession.diagnosticsChecked = true;
        }

        this.ready = this.init();
    }

    private async init() {
        const { profile, recentInteractions } = await userProfileService.bootstrapUser(this.context.userId);
        this.context.shoppingList = await this.listManager.loadActiveList();

        // Carregar preferências persistentes
        const prefs = await userPreferencesService.getPreferences(this.context.userId);
        if (profile.name) this.context.userName = profile.name;
        if (prefs.name) this.context.userName = prefs.name;
        if (prefs.consumption) this.context.consumption = prefs.consumption;
        if (prefs.busTicket) this.context.busTicket = prefs.busTicket;
        recentInteractions.forEach((interaction) => {
            this.conversationState.addMessage(this.context.userId, interaction.role, interaction.content);
        });
        await this.refreshRichContext(true);
        console.log(`[ChatService] Preferences loaded for ${this.context.userId}:`, prefs);
    }

    public async processMessage(message: string): Promise<ChatResponse> {
        await this.ready;
        await this.refreshRichContext();
        const conversationState = this.conversationState;
        console.log(`[ChatService] >>> INCOMING: "${message}"`);
        
        conversationState.addMessage(this.context.userId, 'user', message);
        await userProfileService.recordInteraction(this.context.userId, {
            role: 'user',
            content: message,
        });
        
        const rawResponse = await this._generateRawResponse(message);
        
        const history = conversationState.getHistory(this.context.userId);
        const historyForGemini = history.slice(0, -1); 
        
        const conversationalText = await aiService.generateConversationalResponse(
            rawResponse.text,
            historyForGemini,
            message,
            this.context.richContextSummary,
        );
        
        rawResponse.text = conversationalText;
        conversationState.addMessage(this.context.userId, 'assistant', rawResponse.text);
        await userProfileService.recordInteraction(this.context.userId, {
            role: 'assistant',
            content: rawResponse.text,
            intent: this.context.lastIntent,
        });

        return rawResponse;
    }

    private async _generateRawResponse(message: string): Promise<ChatResponse> {
        const conversationState = this.conversationState;
        conversationState.incrementTurn();

        // ─── 0. GPS: TRATAMENTO DE COORDENADAS DIRETAS ───
        if (message.startsWith('COORDENADAS:') || message.startsWith('[GPS_LOCATION_UPDATE]')) {
            const cleanStr = message.replace('COORDENADAS:', '').replace('[GPS_LOCATION_UPDATE]', '').trim();
            const parts = cleanStr.split(',');
            if (parts.length === 2) {
                const lat = parseFloat(parts[0]);
                const lng = parseFloat(parts[1]);
                if (!isNaN(lat) && !isNaN(lng)) {
                    return this.handleCoords(lat, lng);
                }
            }
        }

        // ─── 0.8. HOTFIX AMNESIA: EARLY RETURN PARA CONFIRMAÇÃO DE COMPRA ───
        if (conversationState.current === 'AWAITING_PURCHASE_CONFIRMATION') {
            const lowMsg = message.toLowerCase().trim();
            const confirmWords = ['ok', 'sim', 'confirmo', 'salva', 'pode salvar', 'yes', 'confirmar', 'isso'];
            const negativeWords = ['cancelar', 'não', 'nao', 'cancela', 'errado', 'descarta'];

            const isConfirm = confirmWords.some(w => lowMsg === w || lowMsg.startsWith(`${w} `));
            const isNegative = negativeWords.some(w => lowMsg === w || lowMsg.startsWith(`${w} `));

            if (isConfirm && this.context.pendingPurchase) {
                console.log(`[ChatService] Early Return: Bypassing NLP for Purchase Confirmation.`);
                const allItems = this.context.pendingMatchResult
                    ? [...this.context.pendingMatchResult.matched, ...this.context.pendingMatchResult.impulse]
                    : undefined;
                const res = await this.purchaseManager.saveConfirmedPurchase(this.context.pendingPurchase, allItems);

                // Finalizar lista se houve match com cupom
                if (this.context.pendingMatchResult && this.context.pendingMatchResult.matched.length > 0) {
                    await this.listManager.finalizeListWithReceipt();
                }

                this.context.pendingPurchase = undefined;
                this.context.pendingMatchResult = undefined;
                conversationState.reset();
                return res;
            }

            if (isNegative && this.context.pendingPurchase) {
                this.context.pendingPurchase = undefined;
                this.context.pendingMatchResult = undefined;
                conversationState.reset();
                return { text: "❌ Fechado, descartei essa nota. Como posso te ajudar agora?" };
            }

            // Se ele digitar algo nada a ver no meio da confirmação:
            return { text: "⚠️ Parceiro, eu preciso que você me responda com **OK** para salvar a nota ou **CANCELAR** para descartar, blz?" };
        }

        // ─── 0.1 FAST GREETING INTERCEPT ───
        const veryShort = message.trim().toLowerCase();
        if (veryShort === '.' || veryShort === '?' || veryShort === '!' || veryShort === 'kole' || veryShort === 'koé') {
            console.log(`[ChatService] Fast-intercepting greeting: "${veryShort}"`);
            return this.handleSaudacao();
        }

        // ─── 0.2 ONBOARDING ANSWER (Sabe como funciona?) ───
        if (conversationState.current === 'AWAITING_ONBOARDING_ANSWER') {
            const lowOnb = message.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
            const isNo = ['nao', 'n', 'nop', 'naum', 'no', 'fala logo', 'que nada', 'negativo', 'nem', 'ixe', 'conta ai', 'explica', 'como'].some(w => lowOnb === w || lowOnb.startsWith(`${w} `));
            const isYes = ['sim', 'yes', 'ok', 'sei', 'ja sei', 'claro', 'conheço', 'conheco', 's', 'sei sim', 'bora', 'ja'].some(w => lowOnb === w || lowOnb.startsWith(`${w} `));

            conversationState.reset();

            if (isNo) {
                return { text: "Show! Aqui é simples:\n\n💬 Você me manda o nome do produto e eu te mostro o **preço mais barato** entre os mercados da sua região.\n\n🛒 Pode montar sua **lista de compras** comigo e eu comparo os preços pra você economizar de verdade.\n\n📸 Tirou foto do cupom fiscal? Me manda que eu registro os preços reais e ainda te mostro se teve **compra por impulso**!\n\nBora lá, me fala o que você precisa! 🏷️" };
            }

            if (isYes) {
                return { text: "Boa! Quem já sabe usar sai na frente! 💪\n\nEm que posso te ajudar hoje?\n• Preço mais barato de algum produto?\n• Montar uma lista de compras?\n• Mercado mais próximo de você?\n\nManda aí! 🛒" };
            }

            // Se ele já mandou um produto direto, trata como busca
            // Cai no fluxo normal abaixo
        }

        // ─── 0.3 TRANSPORT INTERCEPT (FINALIZANDO LISTA) ───
        if (conversationState.current === 'AWAITING_TRANSPORT_MODE_FOR_LIST') {
            const low = message.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
            if (low.includes('carro') || low.includes('uber') || low.includes('moto')) this.context.transportMode = 'car';
            else if (low.includes('onibus') || low.includes('ônibus') || low.includes('bus')) this.context.transportMode = 'bus';
            else if (low.includes('pe') || low.includes('pé') || low.includes('andando')) this.context.transportMode = 'foot';
            else if (low.includes('bike') || low.includes('bicicleta')) this.context.transportMode = 'bike';
            else {
                return { text: "Não entendi bem como você vai. Responde aí: 🚗 Carro, 🚌 Ônibus, 🚶 A pé ou 🚲 Bike?" };
            }

            conversationState.reset();
            return this.handleCalcularTotalLista();
        }

        // Calcula interpretação no início
        const interpretation = await aiService.interpret(message, this.context);

        // ─── 0.5. ONBOARDING (PRIMEIRA MENSAGEM) ───
        if (!this.context.userName && conversationState.current === 'IDLE') {
            const tempIntent = interpretation.intent;

            // HOTFIX 1: Se a primeira mensagem já for um comando de busca/lista, não trava no onboarding.
            if (['consultar_preco_produto', 'consultar_preco_multiplos_produtos', 'criar_lista', 'montar_lista', 'comparar_menor_preco'].includes(tempIntent) || (interpretation.products && interpretation.products.length > 0)) {
                this.context.userName = 'Amigo';
                userPreferencesService.savePreferences(this.context.userId, { name: 'Amigo' });
                // Deixa o fluxo continuar normalmente...
            } else {
                conversationState.transition('AWAITING_NAME', 'save_user_name', null, 'Como quer que eu te chame?');
                return { text: "Fala meu parceiro! 👋 Eu sou o Economiza Fácil, tô aqui pra fazer seu dinheiro render no mercado. Como posso te chamar?" };
            }
        }

        // ─── 1. RESOLVER ESTADO PENDENTE (antes do NLP) ───
        const pending = conversationState.resolveIfPending(message);
        const shouldBypassNameCapture =
            pending?.action === 'save_user_name' &&
            (
                [
                    'consultar_preco_produto',
                    'consultar_preco_multiplos_produtos',
                    'comparar_menor_preco',
                    'criar_lista',
                    'montar_lista',
                    'ofertas_mercado',
                    'ofertas_da_semana',
                    'buscar_categoria',
                    'calcular_total_lista',
                    'melhor_mercado_para_lista',
                    'find_nearby_markets',
                ].includes(interpretation.intent) ||
                Boolean(interpretation.product) ||
                Boolean(interpretation.products?.length)
            );

        if (shouldBypassNameCapture) {
            this.context.userName = this.context.userName || 'Amigo';
            await userPreferencesService.savePreferences(this.context.userId, { name: this.context.userName });
            await userProfileService.updateUserName(this.context.userId, this.context.userName);
            conversationState.reset();
        }

        // ─── 1.5. GATILHO DE SAÍDA DO LOOP (CRIANDO_LISTA -> FINALIZAR) E BLOQUEIOS GLOBAIS ───
        if (conversationState.current === 'CRIANDO_LISTA' || conversationState.current === 'AWAITING_ADD_TO_LIST') {
            const lowMsgRaw = message.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
            const finishWords = ['finalizar', 'finaliza', 'fechar lista', 'fechar a lista', 'so isso', 'e so isso', 'tudo', 'cabou', 'acabou', 'encerra', 'pode finalizar'];
            const isFinish = finishWords.some(w => lowMsgRaw === w || lowMsgRaw.includes(` ${w}`) || lowMsgRaw.startsWith(`${w} `));

            // HOTFIX: "ver lista" / "mostrar lista" → mostrar a lista sem adicionar como item
            const viewListWords = ['ver lista', 'mostrar lista', 'minha lista', 'ver a lista', 'mostra a lista', 'mostra lista', 'exibir lista'];
            const isViewList = viewListWords.some(w => lowMsgRaw === w || lowMsgRaw.startsWith(`${w}`));
            if (isViewList) {
                console.log(`[ChatService] Interceptando 'ver lista' durante CRIANDO_LISTA`);
                const curList = await this.listManager.recoverActiveListItemsOnly();
                if (curList.items.length > 0) {
                    return { text: `${curList.text}Quer adicionar mais itens ou **FINALIZAR**?` };
                }
                return { text: "Sua lista está vazia. Me diga os produtos que quer adicionar!" };
            }

            // HOTFIX 2: Finalizar deve ser exclusivo de CRIANDO_LISTA
            if (isFinish) {
                console.log(`[ChatService] Gatilho de saída ativado: ${message}`);
                conversationState.transition('AWAITING_TRANSPORT_MODE_FOR_LIST', 'choose_transport_for_list', null, 'Como você vai pro mercado?');
                return { text: "Massa, lista fechada! 🛒\nPra eu te dar a rota com o preço **REAL** (somando passagem ou gasolina), me diga: como você vai pro mercado?\n🚗 Carro\n🚌 Ônibus\n🚶 A pé\n🚲 Bike" };
            }

            // HOTFIX 4: Bloqueio de Intenções Globais de Mobilidade durante o loop
            if (lowMsgRaw.includes('km/l') || lowMsgRaw.includes('km ') || lowMsgRaw.includes('carro faz') || lowMsgRaw.match(/\d+\s*(km\/l|km por litro)/)) {
                return { text: "Opa, já guardo essa info do seu transporte! Mas antes, quer adicionar mais itens ou podemos **FINALIZAR** sua lista de produtos?" };
            }
        }

        const intent = shouldBypassNameCapture
            ? interpretation.intent
            : pending ? (pending.action as Intent) : interpretation.intent;
        this.context.lastIntent = intent;

        // VERIFICAÇÃO DE ERRO NA API DA OPENAI:
        if (interpretation.nlpResult?.entities[0]?.value === 'API_ERROR') {
            console.error(`[ChatService] NLP Error Bubble-up: API Falhou silenciosamente.`);
            return { text: "Estou com uma instabilidade no meu cérebro de IA agora, tente de novo em um segundo." };
        }

        // ANTI-AMNÉSIA: Se o estado não é IDLE e o NLP falhou em achar algo forte,
        // força a repetição do estado pendente ou trata como resposta ao estado.
        // E ESPECIAL: Se o LLM disse CANCEL_OR_EXIT (convertido para desconhecido mas validado em AiService)
        if (intent === 'desconhecido' && interpretation.nlpResult?.intent === 'CANCEL_OR_EXIT') {
            console.log(`[ChatService] Cancel or Exit detected. Clearing State.`);
            conversationState.reset();
            return { text: "Tudo bem! Se precisar de algo mais, é só chamar. 👋" };
        }

        if (conversationState.current !== 'IDLE' && (intent === 'saudacao' || intent === 'desconhecido')) {
            console.log(`[ChatService] Amnesia Guard: State "${conversationState.current}" blocked intent "${intent}".`);
            return { text: `Desculpe, ainda estou aguardando sua resposta anterior: **${conversationState.prompt}**` };
        }

        console.log(`[ChatService] Intent: ${intent} | Batch: ${interpretation.isBatch} | Confidence: ${interpretation.confidence}`);

        // ─── 2. HANDLER PARA AÇÕES DO STATE MACHINE ───
        // Quando resolveIfPending retorna, o action pode ser diferente dos intents do NLP
        if (pending && !shouldBypassNameCapture) {
            switch (pending.action) {
                case 'save_user_name': {
                    // Onboarding: salvar nome
                    const userName = message.trim().split(' ')[0];
                    this.context.userName = userName;
                    await userPreferencesService.savePreferences(this.context.userId, { name: userName });
                    await userProfileService.updateUserName(this.context.userId, userName);
                    conversationState.transition('AWAITING_ONBOARDING_ANSWER', 'onboarding_answer', null, 'Sabe como funciona?');
                    return { text: `Fala ${userName}! 👋 Bora economizar? Pode perguntar preço de qualquer produto de supermercado ou mandar a lista do mês que te ajudo a economizar!\n\nSabe como funciona?` };
                }
                case 'list_recovery': {
                    // Usuário decidiu: manter lista existente ou criar nova
                    const lowRecover = pending.originalMessage.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
                    const isNew = ['nova', 'criar', 'criar nova', 'nova lista', 'lista nova', 'nova', 'nao', 'n', 'limpa', 'apaga', 'deleta'].some(w => lowRecover === w || lowRecover.startsWith(`${w} `));

                    if (isNew) {
                        // Deletar lista não-finalizada e começar do zero
                        await this.listManager.deleteActiveList();
                        this.context.shoppingList = [];

                        // Se tinha produtos pendentes (do intent original), criar com eles
                        const pendingProducts = pending.data?.products;
                        if (pendingProducts && pendingProducts.length > 0) {
                            this.context.shoppingList = pendingProducts.map((name: string) => ({ name }));
                            await this.listManager.persistList(this.context.shoppingList);
                            const createdList = await this.listManager.recoverActiveListItemsOnly();
                            conversationState.transition('CRIANDO_LISTA', 'adicionar_item_lista', null, 'Diga os itens');
                            return { text: `✅ Lista nova criada! 🛒\n\n${createdList.text}Quer adicionar mais itens ou **FINALIZAR**?` };
                        }

                        conversationState.transition('CRIANDO_LISTA', 'adicionar_item_lista', null, 'Me diga os produtos!');
                        return { text: "✅ Lista anterior apagada! Me diga os produtos pra nova lista." };
                    }

                    // Manter lista existente → carregar e entrar em CRIANDO_LISTA
                    this.context.shoppingList = await this.listManager.loadActiveList();

                    // Se tinha produtos pendentes, adicionar junto
                    const pendingProds = pending.data?.products;
                    if (pendingProds && pendingProds.length > 0) {
                        for (const p of pendingProds) {
                            if (!this.context.shoppingList.find(i => i.name.toLowerCase() === p.toLowerCase())) {
                                this.context.shoppingList.push({ name: p });
                            }
                        }
                        await this.listManager.persistList(this.context.shoppingList);
                    }

                    const recoveredList = await this.listManager.recoverActiveListItemsOnly();
                    conversationState.transition('CRIANDO_LISTA', 'adicionar_item_lista', null, 'Diga os itens');
                    return { text: `👍 Mantive sua lista! 🛒\n\n${recoveredList.text}Quer adicionar mais itens ou **FINALIZAR**?` };
                }
                case 'add_to_list': {
                    // Usuário disse "sim" após busca de preço único ou fallback de mercado
                    if (pending.confirmed) {
                        let productsToAdd: string[] = [];
                        const msgClean = pending.originalMessage.toLowerCase()
                            .replace(/\b(sim|yes|ok|pode|quero|anota|bora|manda|por favor|claro|com certeza|isso)\b/g, '')
                            .replace(/[,e]/g, ' ')
                            .split(/\s+/)
                            .filter(Boolean);

                        if (msgClean.length > 0) {
                            productsToAdd = msgClean;
                        } else if (pending.data && pending.data !== 'variados') {
                            productsToAdd = [pending.data];
                        } else {
                            conversationState.transition('CRIANDO_LISTA', 'adicionar_item_lista', null, 'Diga os itens');
                            return { text: "Beleza! Me diga quais itens você quer colocar na lista." };
                        }

                        let addedCount = 0;
                        for (const product of productsToAdd) {
                            if (!this.context.shoppingList.find(i => i.name.toLowerCase() === product)) {
                                this.context.shoppingList.push({ name: product });
                                addedCount++;
                            }
                        }
                        await this.listManager.persistList(this.context.shoppingList);
                        const addedText = addedCount > 1 ? `**variados**` : `**${productsToAdd[0]}**`;

                        conversationState.transition('CRIANDO_LISTA', 'adicionar_item_lista', null, 'Diga os itens');
                        return { text: `✅ ${addedCount > 1 ? 'Itens adicionados' : addedText + ' adicionado'} à sua lista! 🛒\n\nDiga mais um produto ou _"ver lista"_ para conferir.` };
                    }
                    return { text: "Beleza, não anotei. O que mais precisa?" };
                }
                case 'add_batch_to_list': {
                    // Usuário disse "sim" após busca de múltiplos produtos
                    // HOTFIX: usar allProducts do context para adicionar TODOS, não só os com preço
                    if (pending.confirmed && pending.data) {
                        const productsToAdd: string[] = this.context.pendingAllProducts || pending.data;

                        for (const p of productsToAdd) {
                            if (!this.context.shoppingList.find(i => i.name.toLowerCase() === p.toLowerCase())) {
                                this.context.shoppingList.push({ name: p });
                            }
                        }
                        this.context.pendingAllProducts = undefined;
                        await this.listManager.persistList(this.context.shoppingList);
                        conversationState.transition('CRIANDO_LISTA', 'adicionar_item_lista', null, 'Diga os itens');
                        return { text: `✅ **${productsToAdd.join(', ')}** adicionados à sua lista! 🛒\n\nDiga mais um produto ou _"ver lista"_ para conferir.` };
                    }
                    this.context.pendingAllProducts = undefined;
                    return { text: "Beleza, não anotei. O que mais precisa?" };
                }
                case 'confirm_list': {
                    if (pending.confirmed) {
                        return this.handleCalcularTotalLista();
                    }
                    return { text: "Beleza! Quer adicionar mais itens ou me fala o que precisa." };
                }
                case 'multi_choice': {
                    const savedProducts: string[] = pending.data || [];
                    if (pending.confirmed) {
                        // Usuário escolheu PREÇO → buscar preço de cada produto
                        console.log(`[ChatService] Multi-choice: PREÇO para ${savedProducts.length} produtos`);
                        const batchResult = await offerEngine.lookupBatch(savedProducts);
                        this.context.pendingAllProducts = savedProducts; // Salvar TODOS para add na lista depois
                        if (batchResult.products.length > 0) {
                            conversationState.transition('AWAITING_ADD_TO_LIST', 'add_batch_to_list', batchResult.products, 'Quer anotar na lista?');
                            return { text: `${batchResult.text}\n\n**Quer que eu anote na sua Lista de Compras? (Sim/Não)**` };
                        }
                        return { text: batchResult.text };
                    } else {
                        // Usuário escolheu LISTA → criar lista de compras
                        console.log(`[ChatService] Multi-choice: LISTA com ${savedProducts.length} produtos`);
                        await this.listManager.archiveActiveList();
                        this.context.shoppingList = savedProducts.map(name => ({ name }));
                        await this.listManager.persistList(this.context.shoppingList);
                        const createdList = await this.listManager.recoverActiveListItemsOnly();
                        conversationState.transition('AWAITING_LIST_CONFIRMATION', 'confirm_list', this.context.shoppingList, 'Finalizar lista?');
                        return { text: `Lista com ${savedProducts.length} itens criada com sucesso! 🛒\n\n${createdList.text}Finalizar lista?` };
                    }
                }
                case 'confirm_expense': {
                    if (pending.confirmed && pending.data) {
                        const { amount, marketName: mktName } = pending.data;
                        // Registrar despesa como compra simplificada
                        await this.purchaseManager.saveConfirmedPurchase({
                            marketName: mktName,
                            total: amount,
                            items: [],
                            date: new Date().toISOString(),
                        });
                        const formattedVal = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(amount);
                        return { text: `✅ Gasto de **${formattedVal}** no **${mktName}** registrado com sucesso!` };
                    }
                    return { text: "Gasto cancelado. O que mais precisa?" };
                }
                case 'CRIANDO_LISTA': {
                    // Adicionar mais itens durante criação de lista
                    const normalizedMessage = message.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
                    if (COURTESY_WORDS.has(normalizedMessage)) {
                        const updatedList = await this.listManager.recoverActiveListItemsOnly();
                        return { text: `${updatedList.text}Pode me dizer mais um produto ou **FINALIZAR** para eu fechar sua lista.` };
                    }

                    const rawNewItems = interpretation.products || interpretation.nlpResult.entities.map(e => e.value);
                    const newItems = cleanProductList(rawNewItems);
                    if (newItems.length > 0) {
                        let addedCount = 0;
                        const duplicates: string[] = [];
                        for (const itemName of newItems) {
                            if (this.context.shoppingList.find(i => i.name.toLowerCase() === itemName.toLowerCase())) {
                                duplicates.push(itemName);
                            } else {
                                this.context.shoppingList.push({ name: itemName });
                                addedCount++;
                            }
                        }
                        await this.listManager.persistList(this.context.shoppingList);
                        const updatedList = await this.listManager.recoverActiveListItemsOnly();

                        let response = '';
                        if (addedCount > 0) response += `Adicionei! 🛒\n\n`;
                        if (duplicates.length > 0) response += `⚠️ **${duplicates.join(', ')}** já ${duplicates.length === 1 ? 'está' : 'estão'} na lista.\n\n`;
                        response += `${updatedList.text}Quer adicionar mais itens ou **FINALIZAR**?`;
                        return { text: response };
                    }
                    // Se digitou algo que não é produto, tenta interpretar como produto mesmo
                    const singleItem = message.trim();
                    if (singleItem.length > 1 && singleItem.length < 50 && !GARBAGE_WORDS.has(singleItem.toLowerCase().trim())) {
                        // Verificar duplicata
                        if (this.context.shoppingList.find(i => i.name.toLowerCase() === singleItem.toLowerCase())) {
                            const updatedList = await this.listManager.recoverActiveListItemsOnly();
                            return { text: `⚠️ **${singleItem}** já está na sua lista!\n\n${updatedList.text}Quer adicionar mais itens ou **FINALIZAR**?` };
                        }
                        this.context.shoppingList.push({ name: singleItem });
                        await this.listManager.persistList(this.context.shoppingList);
                        const updatedList = await this.listManager.recoverActiveListItemsOnly();
                        return { text: `Adicionei **${singleItem}**! 🛒\n\n${updatedList.text}Quer adicionar mais ou **FINALIZAR**?` };
                    }
                    return { text: "Não entendi. Me diga o nome do produto ou **FINALIZAR** para fechar a lista." };
                }
                case 'share_list': {
                    if (pending.confirmed === null) {
                        return { text: "Você prefere ver a rota para o mercado mais barato ou compartilhar a lista no WhatsApp?" };
                    }
                    if (pending.confirmed) {
                        // Rota para o mercado — com cálculo multimodal de transporte
                        const topMarketName = pending.data?.topMarketName;
                        const dest = encodeURIComponent((topMarketName || "Supermercado"));
                        const routeLink = `https://www.google.com/maps/dir/?api=1&destination=${dest}`;

                        // Se o usuário tem localização, calcular custos de transporte
                        if (this.context.userLocation && topMarketName) {
                            try {
                                const nearbyMarkets = await geoDecisionEngine.findNearbyMarkets(
                                    this.context.userLocation.lat,
                                    this.context.userLocation.lng,
                                    50
                                );
                                const marketGeo = nearbyMarkets.find((m: any) =>
                                    m.marketName?.toLowerCase().includes(topMarketName.toLowerCase()) ||
                                    topMarketName.toLowerCase().includes(m.marketName?.toLowerCase() || '')
                                );

                                if (marketGeo?.distance) {
                                    const distKm = marketGeo.distance;
                                    const costs = calculateAllTransportCosts(
                                        distKm,
                                        this.context.consumption || 10,
                                        this.context.busTicket || 4.50
                                    );

                                    const listTotal = pending.data?.listTotal || 0;
                                    const transportLines = costs.map(c => {
                                        const costStr = c.cost > 0 ? `R$ ${c.cost.toFixed(2).replace('.', ',')}` : 'Grátis';
                                        const realTotal = listTotal > 0 ? ` → Total real: **R$ ${(listTotal + c.cost).toFixed(2).replace('.', ',')}**` : '';
                                        return `${c.emoji} **${c.label}**: ${costStr} (${c.time})${realTotal}`;
                                    });

                                    return {
                                        text: `📍 **Rota para ${topMarketName}** (${distKm.toFixed(1)} km)\n\n` +
                                            `🧮 **Custo de deslocamento (ida e volta):**\n${transportLines.join('\n')}\n\n` +
                                            `🔗 ${routeLink}\n\n` +
                                            `💡 _Classe C economiza em cada detalhe! Escolha o meio de transporte que mais cabe no seu bolso._ 💪`
                                    };
                                }
                            } catch (err) {
                                console.error('[ChatService] Transport calc error:', err);
                            }
                        }

                        // Fallback sem localização
                        return { text: `📍 **Rota para o ${topMarketName || 'mercado mais barato'}**\n\n🔗 ${routeLink}\n\n💡 _Compartilhe sua localização para eu calcular o custo de transporte (carro, ônibus, a pé, bike e uber)!_` };
                    } else {
                        // Compartilhar (WhatsApp)
                        const listItems = pending.data?.list || this.context.shoppingList;
                        if (listItems.length === 0) return { text: "Sua lista está vazia." };
                        const share = this.listManager.getShareText(listItems);
                        return { text: `Aqui está sua lista pronta para compartilhar!\n\n${share}`, shareContent: share };
                    }
                }
                default:
                    // Ação não reconhecida do state machine, continuar para o switch de intents
                    break;
            }
        }

        // ─── 2.5. FALLBACK INTELIGENTE: Detectar nomes de rede como busca de mercado ───
        const KNOWN_MARKETS = ['atacadão', 'atacadao', 'extrabom', 'assaí', 'assai', 'carone', 'casagrande', 'rede show', 'redeshow', 'multishow', 'multi show', 'bh supermercados', 'bh', 'supermarket'];
        if (intent === 'consultar_preco_produto' || intent === 'comparar_menor_preco') {
            const searchTerm = (interpretation.product || interpretation.nlpResult.entities[0]?.value || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
            if (searchTerm.length >= 2) {
                const matchedMarket = KNOWN_MARKETS.find(m => searchTerm.includes(m) || m.includes(searchTerm));
                if (matchedMarket && searchTerm.length <= 20) {
                    console.log(`[ChatService] Market Fallback: "${searchTerm}" → ofertas_mercado (matched: ${matchedMarket})`);
                    const purchases = await this.purchaseAnalytics.getFrequentProducts(30);
                    const marketVitrine = await offerEngine.getTopOffersByMarket(searchTerm, purchases);
                    if (marketVitrine.startsWith("Poxa, não encontrei") || marketVitrine.includes("ativas para o mercado agora")) {
                        return { text: marketVitrine };
                    }
                    conversationState.transition('AWAITING_ADD_TO_LIST', 'add_to_list', 'variados', 'Quer que eu adicione as melhores ofertas?');
                    return { text: `${marketVitrine}\n\n**Quer que eu coloque algum desses na sua lista de compras?** 🛒\n(Diga 'Sim' e depois cite os nomes)` };
                }
            }
        }

        // ─── 2.6. MULTI-PRODUTO: Perguntar "preço ou lista?" ───
        const rawMultiProducts = interpretation.products || interpretation.nlpResult.entities.map(e => e.value);
        const multiProducts = cleanProductList(rawMultiProducts);
        const hasMultipleProducts = multiProducts.length >= 2;
        const msgLower = message.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
        const hasExplicitListKeyword = /\b(lista|monte|cria|montar|criar|minha lista)\b/.test(msgLower);

        if (hasMultipleProducts && !hasExplicitListKeyword &&
            (intent === 'criar_lista' || intent === 'consultar_preco_multiplos_produtos' || intent === 'comparar_menor_preco_multiplos_produtos')) {
            console.log(`[ChatService] Multi-product question: ${multiProducts.length} products, asking user intent`);
            conversationState.transition('AWAITING_MULTI_CHOICE', 'multi_choice', multiProducts, '1 ou 2?');
            const productList = multiProducts.map(p => `• ${p}`).join('\n');
            return { text: `Encontrei ${multiProducts.length} produtos:\n${productList}\n\nO que você prefere?\n1️⃣ Ver o **preço** de cada um\n2️⃣ Criar uma **lista de compras**` };
        }

        switch (intent) {
            // ─── Saudação / Ajuda ───
            case 'saudacao':
                return this.handleSaudacao();
            case 'ajuda':
                return { text: "Pode perguntar de tudo: do pão até as comprinhas de farmácia (tipo fralda, camisinha). 🛒\nManda bala no que você precisa:\n• _\"Quanto tá o arroz?\"_\n• _\"Lista: arroz, feijão, frango\"_\n• Mude o mercado: _\"Atacadão\"_ ou _\"Extrabom\"_\n• Envie a foto ou link do Cupom Fiscal!" };

            // ─── Cupom / Compra (via IngestionPipeline + Conferência Lista) ───
            case 'extrair_cupom': {
                const pipelineResult = await ingestionPipeline.processUserSubmission(message);
                const receiptData = pipelineResult.success ? pipelineResult.data : null;

                if (!receiptData) {
                    return { text: pipelineResult.error || "Não consegui extrair os dados. Envie um link de nota fiscal válido, foto do cupom ou placa de preço da prateleira. 📸" };
                }

                // Modo Olheiro (Placa de Prateleira)
                if (pipelineResult.source === 'price_tag') {
                    this.context.pendingPurchase = receiptData;
                    conversationState.transition('AWAITING_PRICE_TAG_CONFIRMATION', 'confirm_price_tag', receiptData, 'Salvar preço da prateleira?');
                    
                    const priceFormatted = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(receiptData.price);
                    let msg = `📸 **Modo Olheiro Ativado!**\n\n`;
                    msg += `Li a etiqueta que você mandou:\n`;
                    msg += `• **Produto:** ${receiptData.product} ${receiptData.brand || ''} ${receiptData.unit || ''}\n`;
                    msg += `• **Preço:** ${priceFormatted}\n`;
                    if (receiptData.marketName) msg += `• **Mercado:** ${receiptData.marketName}\n`;
                    msg += `\nQuer que eu grave isso na base para ajudar a galera? (Responda **OK** ou **Cancelar**)`;
                    
                    return { text: msg };
                }

                // Carregar lista ativa e fazer matching (Fluxo Normal NF)
                const activeList = await this.listManager.loadActiveList();
                const matchResult = matchReceiptToList(receiptData.items || [], activeList);

                // Armazenar no contexto para uso na confirmação
                this.context.pendingPurchase = receiptData;
                this.context.pendingMatchResult = matchResult;

                // Gerar mensagem de conferência
                const conference = this.purchaseManager.formatReceiptConference(receiptData, matchResult);

                conversationState.transition('AWAITING_PURCHASE_CONFIRMATION', 'confirm_purchase', receiptData, 'OK para confirmar');
                return { text: conference.text };
            }
            case 'confirmar_registro':
                if (this.context.pendingPurchase) {
                    if (this.context.pendingPurchase.type === 'price_tag') {
                        // TODO: Gravar no banco de ofertas de forma global
                        console.log("[ChatService] Preço de prateleira salvo na base:", this.context.pendingPurchase);
                        this.context.pendingPurchase = undefined;
                        conversationState.reset();
                        return { text: "✅ Preço gravado com sucesso! Valeu por fortalecer a comunidade! 👊" };
                    }

                    const allItems = this.context.pendingMatchResult
                        ? [...this.context.pendingMatchResult.matched, ...this.context.pendingMatchResult.impulse]
                        : undefined;
                    const res = await this.purchaseManager.saveConfirmedPurchase(this.context.pendingPurchase, allItems);

                    // Finalizar lista se houve match com cupom
                    if (this.context.pendingMatchResult && this.context.pendingMatchResult.matched.length > 0) {
                        await this.listManager.finalizeListWithReceipt();
                    }

                    this.context.pendingPurchase = undefined;
                    this.context.pendingMatchResult = undefined;
                    conversationState.reset();
                    return res;
                }
                return { text: "Não tenho nenhuma compra pendente para confirmar agora." };
            case 'cancelar_compra':
                if (this.context.pendingPurchase) {
                    this.context.pendingPurchase = undefined;
                    this.context.pendingMatchResult = undefined;
                    conversationState.reset();
                    return { text: "❌ Fechado. Ação cancelada e dados descartados." };
                }
                return { text: "Não tenho nenhuma compra pendente para cancelar." };
            case 'finalizar_compra':
                return { text: "Para registrar uma compra real, envie uma foto do cupom, QR Code ou do preço na prateleira. 📸" };

            // ─── Multi-Produto (TOP 3 por produto + proativo) ───
            case 'consultar_preco_multiplos_produtos':
            case 'comparar_menor_preco_multiplos_produtos': {
                const products = interpretation.products || interpretation.nlpResult.entities.map(e => e.value);
                if (products.length === 0) return { text: "Quais produtos você gostaria de consultar?" };

                const batchResult = await offerEngine.lookupBatch(products, this.context.userLocation, this.context.transportMode, this.context.consumption);
                this.context.pendingAllProducts = products; // Salvar TODOS para add na lista depois

                if (batchResult.products.length > 0) {
                    conversationState.transition('AWAITING_ADD_TO_LIST', 'add_batch_to_list', batchResult.products, 'Quer que eu anote isso na sua Lista de Compras?');
                    return { text: `${batchResult.text}\n\n**Quer que eu anote isso na sua Lista de Compras? (Sim/Não)**` };
                }
                return { text: batchResult.text };
            }

            // ─── Geolocalização ───
            case 'compartilhar_localizacao':
                return this.handleLocation();
            case 'find_nearby_markets':
                return this.handleFindNearbyMarkets();
            case 'definir_transporte':
                return this.handleTransport(message.toLowerCase());
            case 'definir_consumo':
                return this.handleConsumption(message.toLowerCase());

            // ─── Ofertas Específicas de um Mercado ───
            case 'ofertas_mercado':
            case 'get_market_offers': {
                const marketName = interpretation.nlpResult.entities[0]?.value;
                if (!marketName) return { text: "De qual mercado você quer ver as ofertas?" };
                // Carregar histórico de compras para cruzar
                const mktPurchases = await this.purchaseAnalytics.getFrequentProducts(30);
                const marketVitrine = await offerEngine.getTopOffersByMarket(marketName, mktPurchases);
                if (marketVitrine.startsWith("Poxa, não encontrei")) {
                    return { text: marketVitrine };
                }
                conversationState.transition('AWAITING_ADD_TO_LIST', 'add_to_list', 'variados', 'Quer que eu adicione as melhores ofertas?');
                return { text: `${marketVitrine}\n\n**Quer que eu coloque algum desses na sua lista de compras?** 🛒\n(Diga 'Sim' e depois cite os nomes)` };
            }

            // ─── Ofertas da Semana ───
            case 'ofertas_da_semana': {
                const vitrine = await offerEngine.getWeeklyVitrine();
                return { text: vitrine };
            }

            // ─── Ofertas por Categoria ───
            case 'buscar_categoria': {
                const categoryName = interpretation.nlpResult.entities[0]?.value;
                if (!categoryName) return { text: "Qual departamento ou categoria você quer buscar? (ex: Carnes, Limpeza, Cervejas)" };
                const catVitrine = await offerEngine.getCategoryVitrine(categoryName);
                if (catVitrine.startsWith("Poxa") || catVitrine.startsWith("As ofertas")) {
                    return { text: catVitrine };
                }
                conversationState.transition('AWAITING_ADD_TO_LIST', 'add_to_list', 'variados', 'Quer que eu adicione algum item?');
                return { text: `${catVitrine}\n\n**Gostou de algo? Quer que eu adicione à sua lista de compras?** 🛒\n(Diga 'Sim' e depois cite os nomes)` };
            }

            // ─── Histórico de Preços (Global) ───
            case 'consultar_historico_global': {
                const product = interpretation.product || interpretation.nlpResult.entities[0]?.value;
                if (!product) return { text: "Qual produto você quer ver o histórico de preço?" };
                const targetDate = this.extractDateFromMessage(message);
                const historicalText = await offerEngine.getHistoricalPrices(product, targetDate || undefined);
                return { text: historicalText };
            }

            // ─── Atualização de Registro Financeiro Pessoal ───
            case 'registrar_gasto': {
                const amount = interpretation.nlpResult.entities[0]?.amount;
                const marketNameGasto = interpretation.nlpResult.entities[0]?.value;

                if (amount === undefined || !marketNameGasto || marketNameGasto === 'desconhecido') {
                    return { text: "Para registrar um gasto financeiro, preciso do valor exato e do nome da loja. Exemplo: _'Gastei 150 reais no Atacadão'_." };
                }

                const payload = { amount, marketName: marketNameGasto };
                const formattedValue = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(amount);

                conversationState.transition('AWAITING_EXPENSE_CONFIRMATION', 'confirm_expense', payload, 'Confirmar gasto?');
                return { text: `📝 Entendi. Você gastou **${formattedValue}** no mercado **${marketNameGasto.toUpperCase()}**?\n\n(Diga *Sim* para confirmar ou *Não* para cancelar)` };
            }

            // ─── Análise de Gastos Pessoal ───
            case 'analise_gastos_pessoal': {
                const analyticsTerm = interpretation.product || interpretation.nlpResult.entities[0]?.value;
                const days = this.extractDaysFromMessage(message);

                if (analyticsTerm) {
                    const summary = await this.purchaseAnalytics.calculateCategoryAverage(analyticsTerm, days);
                    return { text: this.purchaseAnalytics.formatCategoryAnalysis(summary, analyticsTerm, days) };
                } else {
                    const top = await this.purchaseAnalytics.getTopSpending(days);
                    return { text: this.purchaseAnalytics.formatTopSpending(top, days) };
                }
            }

            // ─── Histórico de Compras do Usuário ───
            case 'gerenciar_lista':
            case 'mostrar_lista': {
                const curList = await this.listManager.recoverActiveListItemsOnly();
                if (curList.items.length > 0) {
                    conversationState.transition('AWAITING_LIST_CONFIRMATION', 'confirm_list', this.context.shoppingList, 'Finalizar lista?');
                    return { text: `${curList.text}Finalizar lista?` };
                }
                return { text: "Sua lista está vazia no momento. Diga algo como _'lista: arroz, feijão'_ para começar!" };
            }

            case 'limpar_lista':
                await this.listManager.archiveActiveList();
                this.context.shoppingList = [];
                return { text: "Lista limpa com sucesso! Quando quiser começar uma nova, é só me falar os itens." };

            case 'ver_ultima_lista':
                return this.listManager.getLastList();

            case 'ver_historico_compras':
            case 'ver_gastos_recentes': {
                const days = interpretation.nlpResult.entities[0]?.days || this.extractDaysFromMessage(message);
                const endDate = new Date().toISOString().split('T')[0];
                const startDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
                const result = await this.purchaseAnalytics.getTotalSpentInPeriod(startDate, endDate);
                return { text: this.purchaseAnalytics.formatPeriodSummary(result, days) };
            }

            case 'ver_ultima_compra': {
                const purchase = await this.purchaseAnalytics.getLastPurchase();
                return { text: this.purchaseAnalytics.formatLastPurchase(purchase) };
            }

            case 'ver_padrao_consumo': {
                const daysPattern = interpretation.nlpResult.entities[0]?.days || this.extractDaysFromMessage(message);
                const pattern = await this.purchaseAnalytics.getConsumptionPattern(daysPattern);
                const predictivePlan = await predictiveShoppingService.buildMonthlyPlan(this.context.userId);
                const predictiveText = predictiveShoppingService.formatMonthlyPlan(predictivePlan);
                return { text: `${this.purchaseAnalytics.formatConsumptionPattern(pattern, daysPattern)}\n\n${predictiveText}` };
            }

            // ─── Lista ───
            case 'montar_lista':
            case 'criar_lista': {
                const rawItems = interpretation.products || interpretation.nlpResult.entities.map(e => e.value);
                const items = cleanProductList(rawItems);

                // Verificar se já existe uma lista ativa não-finalizada
                const existingList = await this.listManager.loadActiveList();
                if (existingList.length > 0) {
                    console.log(`[ChatService] Lista ativa encontrada com ${existingList.length} itens. Perguntando ao usuário.`);
                    conversationState.transition('AWAITING_LIST_RECOVERY', 'list_recovery', { products: items }, 'Manter ou criar nova?');
                    const preview = existingList.slice(0, 5).map(i => i.name).join(', ');
                    const moreText = existingList.length > 5 ? ` e mais ${existingList.length - 5}` : '';
                    return { text: `📋 Você já tem uma lista com **${existingList.length} itens** (${preview}${moreText}).\n\nQuer **manter** essa lista e continuar adicionando ou **criar uma nova** do zero?` };
                }

                if (items.length === 0) {
                    conversationState.transition('CRIANDO_LISTA', 'adicionar_item_lista', null, 'Me dê os produtos que eu crio uma lista pra você bem rápida e econômica!');
                    return { text: "Me dê os produtos que eu crio uma lista pra você bem rápida e econômica!" };
                }

                // Criar nova lista
                const entities = interpretation.nlpResult.entities;
                this.context.shoppingList = items.map((name, idx) => ({
                    name,
                    quantity: entities[idx]?.quantity,
                    unit: entities[idx]?.unit
                }));
                await this.listManager.persistList(this.context.shoppingList);

                const createdList = await this.listManager.recoverActiveListItemsOnly();
                conversationState.transition('CRIANDO_LISTA', 'adicionar_item_lista', null, 'Diga os itens');
                return { text: `Lista com ${items.length} itens criada! 🛒\n\n${createdList.text}Quer adicionar mais itens ou **FINALIZAR**?` };
            }
            case 'adicionar_item_lista': {
                const addEntities = interpretation.nlpResult.entities;
                const rawAddItems = interpretation.products?.length ? interpretation.products : (interpretation.product ? [interpretation.product] : addEntities.map(e => e.value));
                const addItems = cleanProductList(rawAddItems);
                if (addItems.length === 0) return { text: "Quais itens você quer adicionar?" };
                addItems.forEach((name, idx) => {
                    if (!this.context.shoppingList.find(i => i.name === name)) {
                        this.context.shoppingList.push({
                            name,
                            quantity: addEntities[idx]?.quantity,
                            unit: addEntities[idx]?.unit
                        });
                    }
                });
                await this.listManager.persistList(this.context.shoppingList);
                const addResult = await this.listManager.recoverActiveListItemsOnly();
                conversationState.transition('AWAITING_LIST_CONFIRMATION', 'confirm_list', this.context.shoppingList, 'Finalizar lista?');
                return { text: `Adicionei à sua lista.\n\n${addResult.text}Finalizar lista?` };
            }
            case 'remover_item_lista': {
                const removeItems = interpretation.products?.length ? interpretation.products : (interpretation.product ? [interpretation.product] : interpretation.nlpResult.entities.map(e => e.value));
                if (removeItems.length === 0) return { text: "Quais itens você quer tirar da lista?" };
                this.context.shoppingList = this.context.shoppingList.filter(
                    item => !removeItems.some(r => item.name.toLowerCase().includes(r.toLowerCase()))
                );
                await this.listManager.persistList(this.context.shoppingList);
                const rmResult = await this.listManager.recoverActiveListItemsOnly();
                conversationState.transition('AWAITING_LIST_CONFIRMATION', 'confirm_list', this.context.shoppingList, 'Finalizar lista?');
                return { text: `Pronto, removi. Sua lista atualizada:\n\n${rmResult.text}Finalizar lista?` };
            }
            case 'calcular_total_lista':
            case 'melhor_mercado_para_lista': {
                return this.handleCalcularTotalLista();
            }
            case 'compartilhar_lista':
                if (this.context.shoppingList.length === 0) return { text: "Sua lista está vazia." };
                const share = this.listManager.getShareText(this.context.shoppingList);
                return { text: `Aqui está sua lista pronta para compartilhar:\n\n${share}`, shareContent: share };

            // ─── Preço Único (PROATIVO: oferece adicionar na lista) ───
            case 'consultar_preco_produto':
            case 'comparar_menor_preco': {
                const term = interpretation.product || interpretation.nlpResult.entities[0]?.value;
                if (!term) return { text: "Quais produtos você quer saber o preço?" };
                this.context.lastProduct = term;
                const priceText = await offerEngine.lookupSingle(term, this.context.userLocation, this.context.transportMode, this.context.consumption);

                if (priceText.startsWith("Não encontrei ofertas")) {
                    return { text: `Poxa, ainda não encontrei ofertas vigentes para **${term}** hoje.` };
                }

                conversationState.transition('AWAITING_ADD_TO_LIST', 'add_to_list', term, 'Quer que eu anote isso na sua Lista de Compras?');
                return { text: `${priceText}\n\n**Quer que eu anote isso na sua Lista de Compras? (Sim/Não)**` };
            }

            default:
                return { text: "Como posso ajudar com suas compras hoje? Posso consultar preços, montar sua lista ou ver seu histórico." };
        }
    }

    public async processImage(imageData: Uint8Array): Promise<ChatResponse> {
        await this.ready;
        await this.refreshRichContext();
        const conversationState = this.conversationState;
        console.log(`[ChatService] >>> INCOMING IMAGE`);
        conversationState.incrementTurn();
        this.context.lastIntent = 'extrair_cupom';
        conversationState.addMessage(this.context.userId, 'user', '[IMAGEM]');
        await userProfileService.recordInteraction(this.context.userId, {
            role: 'user',
            content: '[IMAGEM]',
            intent: 'extrair_cupom',
        });

        const pipelineResult = await ingestionPipeline.processUserSubmission(imageData);
        const receiptData = pipelineResult.data;

        if (!pipelineResult.success || !pipelineResult.data) {
            return { text: pipelineResult.error || "Não consegui extrair os dados da imagem. Envie uma foto mais nítida do cupom ou QR Code." };
        }

        if (pipelineResult.source === 'price_tag') {
            const response = await this.savePriceTag(pipelineResult.data);
            conversationState.addMessage(this.context.userId, 'assistant', response.text);
            await userProfileService.recordInteraction(this.context.userId, {
                role: 'assistant',
                content: response.text,
                intent: 'extrair_cupom',
            });
            return response;
        }

        const activeList = await this.listManager.loadActiveList();
        const matchResult = matchReceiptToList(receiptData.items || [], activeList);

        this.context.pendingPurchase = receiptData;
        this.context.pendingMatchResult = matchResult;

        const conference = this.purchaseManager.formatReceiptConference(receiptData, matchResult);
        conversationState.transition('AWAITING_PURCHASE_CONFIRMATION', 'confirm_purchase', receiptData, 'OK para confirmar');
        conversationState.addMessage(this.context.userId, 'assistant', conference.text);
        await userProfileService.recordInteraction(this.context.userId, {
            role: 'assistant',
            content: conference.text,
            intent: 'extrair_cupom',
        });

        return { text: conference.text };
    }

    // ─── Extras & Saudações ───

    private handleSaudacao(): ChatResponse {
        const conversationState = this.conversationState;
        const name = this.context.userName && this.context.userName !== 'Amigo'
            ? ` ${this.context.userName}` : '';
        if (!this.context.userName) {
            conversationState.transition('AWAITING_NAME', 'save_user_name', null, 'Como quer que eu te chame?');
            return { text: "Fala meu parceiro! 👋 Eu sou o Economiza Fácil, tô aqui pra fazer seu dinheiro render no mercado. Como posso te chamar?" };
        }
        return { text: `Fala${name}! 👋\nPode mandar o nome de um produto, pedir uma oferta ou montar sua lista.` };
    }

    private handleLocation(): ChatResponse {
        return {
            text: "📍 Para calcular as rotas e o custo real, me diga em qual bairro e cidade você está (ex: Jardim Camburi, Vitória)."
        };
    }

    private handleTransport(msg: string): ChatResponse {
        const conversationState = this.conversationState;
        if (msg.includes('carro')) {
            this.context.transportMode = 'car';
            conversationState.transition('AWAITING_CONSUMPTION', 'set_consumption', null, 'Qual o consumo médio (km/l)?');
            return { text: "Entendido! Você vai de **🚗 carro**. Qual o consumo médio (km/l)? _(padrão: 10 km/l)_" };
        }
        if (msg.includes('onibus') || msg.includes('ônibus') || msg.includes('bus')) {
            this.context.transportMode = 'bus';
            const priceMatch = msg.match(/\d+([.,]\d+)?/);
            if (priceMatch) {
                const val = parseFloat(priceMatch[0].replace(',', '.'));
                this.context.busTicket = val;
                userPreferencesService.savePreferences(this.context.userId, { busTicket: val });
            }
            conversationState.reset();
            return { text: `🚌 Você vai de **ônibus**! Considerei o valor da passagem como **R$ ${this.context.busTicket || 4.50}**.\nSe o valor for diferente, me diga: _'passagem custante X'_ ou mude para 🚗 carro.` };
        }
        this.context.transportMode = 'foot';
        conversationState.reset();
        return { text: "Ótimo! Você vai **🚶 a pé**. Custo de deslocamento: **R$ 0,00**. Vou considerar apenas mercados bem próximos." };
    }

    private handleConsumption(msg: string): ChatResponse {
        const match = msg.match(/\d+([.,]\d+)?/);
        if (match) {
            const val = parseFloat(match[0].replace(',', '.'));
            this.context.consumption = val;
            userPreferencesService.savePreferences(this.context.userId, { consumption: val });
            return { text: `Entendido! Gravei o consumo de **${val} km/l** nas suas preferências. Recomendações agora serão mais precisas! 🚗💨` };
        }
        return { text: "Não consegui identificar o valor. Pode digitar apenas o número do consumo (ex: 12.5)?" };
    }

    private handleCoords(lat: number, lng: number): ChatResponse {
        this.context.userLocation = { lat, lng, address: `${lat.toFixed(4)}, ${lng.toFixed(4)}` };
        return { text: `📍 Localização GPS recebida! Agora posso calcular distâncias reais aos mercados.\n\nVocê vai de **carro**, **ônibus** ou **a pé**?` };
    }

    private async handleFindNearbyMarkets(): Promise<ChatResponse> {
        if (!this.context.userLocation) {
            this.context.userLocation = { lat: -20.2975, lng: -40.3015, address: "Vitória, ES" }; // Mock sem fricção para a classe C
        }
        const markets = await geoDecisionEngine.findNearbyMarkets(
            this.context.userLocation.lat,
            this.context.userLocation.lng,
        );
        return { text: geoDecisionEngine.formatNearbyMarketsResponse(markets) };
    }

    private async handleCalcularTotalLista(): Promise<ChatResponse> {
        const conversationState = this.conversationState;
        if (this.context.shoppingList.length === 0) {
            return { text: "Sua lista está vazia." };
        }

        const comparative = await this.listManager.generateComparativeTemplate();

        // Sugestão inteligente baseada na categoria dominante da lista
        const suggestion = await offerEngine.getSmartSuggestion(this.context.shoppingList);
        const suggestionText = suggestion ? suggestion.text : '';

        conversationState.transition('AWAITING_SHARE_CONFIRMATION', 'share_list', { list: this.context.shoppingList, topMarketName: comparative.topMarketName }, 'Quer compartilhar essa lista?');
        return { text: `${comparative.text}${suggestionText}\n\n**Quer a lista com o mercado mais barato e próximo a você ou já quer compartilhar essa lista via WhatsApp?**\n1️⃣ Mercado mais barato (Rota)\n2️⃣ Compartilhar no WhatsApp` };
    }

    private async savePriceTag(tagData: any): Promise<ChatResponse> {
        const marketName = tagData.marketName || 'Mercado Desconhecido';

        try {
            const { addDoc, collection } = await import('firebase/firestore');
            const { db } = await import('../firebase');

            await addDoc(collection(db, 'offers'), {
                name: tagData.product,
                productName: tagData.product,
                brand: tagData.brand || '',
                price: tagData.price,
                marketName,
                source: 'community_vision',
                reportedBy: this.context.userId,
                createdAt: new Date().toISOString(),
                expiresAt: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
            });

            return {
                text: `ðŸ“¸ **Foto de Prateleira Reconhecida!**\n\nIdentifiquei:\nðŸ·ï¸ ${tagData.product} ${tagData.brand ? `(${tagData.brand})` : ''}\nðŸ’° R$ ${tagData.price.toFixed(2).replace('.', ',')}\nðŸª ${marketName}\n\nObrigado por contribuir com a comunidade! Essa oferta jÃ¡ estÃ¡ no nosso banco de dados. ðŸ¤`
            };
        } catch (err) {
            console.error('[ChatService] Erro ao salvar price_tag:', err);
            return { text: 'âŒ Consegui ler a etiqueta, mas deu erro ao salvar no banco. Tente novamente mais tarde.' };
        }
    }

    private async refreshRichContext(force: boolean = false): Promise<void> {
        const now = Date.now();
        if (!force && now - this.lastContextRefreshAt < 30000) {
            return;
        }

        const richContext = await userContextService.buildRichContext(this.context.userId, this.context.userName);
        this.context.richContextSummary = richContext.summary;
        this.context.predictedNeeds = richContext.predictedNeeds;
        this.lastContextRefreshAt = now;
    }

    private extractDateFromMessage(msg: string): string | null {
        const MONTHS: Record<string, string> = {
            'janeiro': '01', 'jan': '01', 'fevereiro': '02', 'fev': '02',
            'marco': '03', 'março': '03', 'mar': '03', 'abril': '04', 'abr': '04',
            'maio': '05', 'mai': '05', 'junho': '06', 'jun': '06',
            'julho': '07', 'jul': '07', 'agosto': '08', 'ago': '08',
            'setembro': '09', 'set': '09', 'outubro': '10', 'out': '10',
            'novembro': '11', 'nov': '11', 'dezembro': '12', 'dez': '12',
        };

        const low = msg.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

        for (const [name, num] of Object.entries(MONTHS)) {
            const re = new RegExp(name + '[\\s/]*(\\d{4})', 'i');
            const m = low.match(re);
            if (m) return `${m[1]}-${num}-15`;
        }

        const mmyyyy = low.match(/(\d{2})[\/\-](\d{4})/);
        if (mmyyyy) return `${mmyyyy[2]}-${mmyyyy[1]}-15`;

        const full = low.match(/(\d{2})[\/\-](\d{2})[\/\-](\d{4})/);
        if (full) return `${full[3]}-${full[2]}-${full[1]}`;

        const year = new Date().getFullYear();
        for (const [name, num] of Object.entries(MONTHS)) {
            if (low.includes(name)) return `${year}-${num}-15`;
        }

        return null;
    }

    private extractDaysFromMessage(msg: string): number {
        const low = msg.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

        const daysMatch = low.match(/(\d+)\s*dias?/);
        if (daysMatch) return parseInt(daysMatch[1]);

        const monthsMatch = low.match(/(\d+)\s*mes(es)?/);
        if (monthsMatch) return parseInt(monthsMatch[1]) * 30;

        if (low.includes('semana passada') || low.includes('ultima semana')) return 7;
        if (low.includes('mes passado') || low.includes('ultimo mes')) return 30;
        if (low.includes('2 meses') || low.includes('dois meses')) return 60;
        if (low.includes('3 meses') || low.includes('tres meses')) return 90;
        if (low.includes('6 meses') || low.includes('seis meses')) return 180;
        if (low.includes('ano') || low.includes('12 meses')) return 365;

        return 30;
    }
}

class ChatService {
    private readonly sessions = new Map<string, ChatSession>();

    private getSession(userId: string = 'default_user'): ChatSession {
        const normalizedUserId = userId || 'default_user';

        if (!this.sessions.has(normalizedUserId)) {
            this.sessions.set(normalizedUserId, new ChatSession(normalizedUserId));
        }

        return this.sessions.get(normalizedUserId)!;
    }

    public async processMessage(message: string, userId: string = 'default_user'): Promise<ChatResponse> {
        return this.getSession(userId).processMessage(message);
    }

    public async processImage(imageData: Uint8Array, userId: string = 'default_user'): Promise<ChatResponse> {
        return this.getSession(userId).processImage(imageData);
    }
}

export const chatService = new ChatService();
