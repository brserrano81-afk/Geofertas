// ─────────────────────────────────────────────
// ConversationStateService — Gerencia contexto contínuo
// ─────────────────────────────────────────────

export interface MessageLog {
    role: 'user' | 'assistant';
    content: string;
}

export type ConversationStatus =
    | 'IDLE'
    | 'AWAITING_NAME'
    | 'AWAITING_ADD_TO_LIST'
    | 'AWAITING_LIST_ITEMS'
    | 'AWAITING_LIST_CONFIRMATION'
    | 'AWAITING_PURCHASE_CONFIRMATION'
    | 'AWAITING_PRICE_TAG_CONFIRMATION'
    | 'AWAITING_EXPENSE_CONFIRMATION'
    | 'AWAITING_CLARIFICATION'
    | 'AWAITING_TRANSPORT_MODE_FOR_LIST'
    | 'AWAITING_TRANSPORT_FOR_LIST'
    | 'AWAITING_TRANSPORT_CONSUMPTION'
    | 'AWAITING_CONSUMPTION'
    | 'AWAITING_SHARE_CONFIRMATION'
    | 'AWAITING_MULTI_CHOICE'
    | 'AWAITING_ONBOARDING_ANSWER'
    | 'AWAITING_LIST_RECOVERY'
    | 'CRIANDO_LISTA';

export class ConversationStateService {
    public current: ConversationStatus = 'IDLE';
    public action: string = '';
    public data: any = null;
    public prompt: string = '';
    private turnCount: number = 0;
    private history: Record<string, MessageLog[]> = {};

    addMessage(userId: string, role: 'user' | 'assistant', content: string) {
        if (!this.history[userId]) {
            this.history[userId] = [];
        }
        this.history[userId].push({ role, content });
        if (this.history[userId].length > 10) {
            this.history[userId].shift();
        }
    }

    getHistory(userId: string): MessageLog[] {
        return this.history[userId] || [];
    }

    clearHistory(userId: string) {
        this.history[userId] = [];
    }

    transition(status: ConversationStatus, action: string, data: any, prompt: string) {
        console.log(`[State] ${this.current} → ${status} (action: ${action})`);
        this.current = status;
        this.action = action;
        this.data = data;
        this.prompt = prompt;
    }

    reset() {
        console.log(`[State] RESET from ${this.current}`);
        this.current = 'IDLE';
        this.action = '';
        this.data = null;
        this.prompt = '';
    }

    incrementTurn() {
        this.turnCount++;
    }

    get turns() {
        return this.turnCount;
    }

    isConfirmation(msg: string): boolean {
        const low = msg.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
        const yesWords = ['sim', 'yes', 'ok', 'pode', 'quero', 'anota', 'bora', 'manda', 'por favor', 'claro', 'com certeza', 'isso'];
        return yesWords.some(w => low === w || low.startsWith(`${w} `) || low.startsWith(`${w},`));
    }

    isNegation(msg: string): boolean {
        const low = msg.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
        const noWords = ['nao', 'no', 'n', 'nem', 'nunca', 'cancela', 'cancelar', 'deixa', 'nope', 'nop', 'naum', 'fala logo', 'que nada', 'negativo', 'ixe'];
        return noWords.some(w => low === w || low.startsWith(`${w} `));
    }

    resolveIfPending(message: string): { action: string; data: any; confirmed: boolean; originalMessage: string } | null {
        if (this.current === 'IDLE') return null;

        const isYes = this.isConfirmation(message);
        const isNo = this.isNegation(message);

        // Se é um estado "quente" que espera confirmação simples:
        const hotStates: ConversationStatus[] = [
            'AWAITING_LIST_CONFIRMATION',
            'AWAITING_PURCHASE_CONFIRMATION',
            'AWAITING_PRICE_TAG_CONFIRMATION',
            'AWAITING_EXPENSE_CONFIRMATION',
            'AWAITING_ADD_TO_LIST',
            'AWAITING_NAME',
            'AWAITING_CLARIFICATION',
            'AWAITING_TRANSPORT_FOR_LIST',
            'AWAITING_TRANSPORT_CONSUMPTION',
            'AWAITING_ONBOARDING_ANSWER',
            'AWAITING_LIST_RECOVERY',
        ];

        if (hotStates.includes(this.current)) {
            if (isYes || isNo || this.current === 'AWAITING_NAME' || this.current === 'AWAITING_TRANSPORT_FOR_LIST' || this.current === 'AWAITING_TRANSPORT_CONSUMPTION') {
                const result = {
                    action: this.action || this.current,
                    data: this.data,
                    confirmed: isYes || this.current === 'AWAITING_NAME' || this.current === 'AWAITING_TRANSPORT_FOR_LIST' || this.current === 'AWAITING_TRANSPORT_CONSUMPTION',
                    originalMessage: message,
                };
                this.reset();
                return result;
            }
        }

        // Estado CRIANDO_LISTA: deixa o ChatService decidir
        if (this.current === 'CRIANDO_LISTA') {
            return {
                action: 'CRIANDO_LISTA',
                data: this.data,
                confirmed: true,
                originalMessage: message,
            };
        }

        // Estado AWAITING_SHARE_CONFIRMATION: rotativa de mercado vs compartilhar
        if (this.current === 'AWAITING_SHARE_CONFIRMATION') {
            const low = message.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
            const isMercado = /\b(mercado|barato|proximo|próximo|rota|1)\b/.test(low);
            const isShare = /\b(compartilhar|whatsapp|zap|mandar|enviar|2)\b/.test(low);

            let confirmed = isMercado; // true = mercado, false = share
            if (isShare) confirmed = false;
            // Default "sim" para a primeira opção (mercado) se não explicitar
            if (isYes && !isMercado && !isShare) confirmed = true;

            if (isMercado || isShare || isYes) {
                const result = {
                    action: 'share_list',
                    data: this.data,
                    confirmed,
                    originalMessage: message,
                };
                this.reset();
                return result;
            }
            if (isNo) {
                this.reset();
                return { action: 'share_list', data: this.data, confirmed: false, originalMessage: message };
            }
        }

        // Estado AWAITING_MULTI_CHOICE: preço ou lista
        if (this.current === 'AWAITING_MULTI_CHOICE') {
            const low = message.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
            const isPrice = /\b(preco|precos|1|ver preco|comparar|quanto|valor)\b/.test(low);
            const isList = /\b(lista|2|criar|montar|cria|monta)\b/.test(low);
            if (isPrice || isList) {
                const result = {
                    action: 'multi_choice',
                    data: this.data,
                    confirmed: isPrice, // true = preço, false = lista
                    originalMessage: message,
                };
                this.reset();
                return result;
            }
            // Se não entendeu, deixa cair no NLP normal
            this.reset();
            return null;
        }

        return null;
    }
}

export const conversationState = new ConversationStateService();
