import { Routes, Route, Navigate } from "react-router-dom";
import Layout from "./Layout";

import Home from "../pages/Home";
import CriarLista from "../pages/Criarlista";
import ConsultarPreco from "../pages/ConsultarPreco";
import ResultadoLista from "../pages/ResultadoLista";
import Lista from "../pages/Lista";
import MinhasListas from "../pages/MinhasListas";

export default function AppRoutes() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/criar-lista" element={<CriarLista />} />
        <Route path="/consultar-preco" element={<ConsultarPreco />} />
        <Route path="/resultado-lista" element={<ResultadoLista />} />

        {/* ✅ novo */}
        <Route path="/lista/:userId/:listId" element={<Lista />} />
        <Route path="/minhas-listas" element={<MinhasListas />} />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}
